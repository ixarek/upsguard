(*
Module: NutUpsmonConf
 Parses /etc/nut/upsmon.conf

Author: Raphael Pinson <raphink@gmail.com>
        Frederic Bohe  <fredericbohe@eaton.com>

About: License
  This file is licensed under the GPL.

About: Lens Usage
  Sample usage of this lens in augtool

    * Print all notification messages
      > print /files/etc/nut/upsmon.conf/NOTIFYMSG

About: Configuration files
  This lens applies to /etc/nut/upsmon.conf. See <filter>.
*)

module NutUpsmonConf =
  autoload upsmon_xfm


(************************************************************************
 * Group:                 UPSMON.CONF
 *************************************************************************)

(* general *)
let del_spc  = Util.del_opt_ws ""
let sep_spc  = Util.del_ws_spc
let eol      = Util.eol
let num      = /[0-9]+/
let word     = /[^"#; \t\n]+/
let empty    = Util.empty
let comment  = Util.comment
let quoted_string = del "\"" "\"" . store /[^"\n]+/ . del "\"" "\""

(* UPS identifier
 * <upsname>[@<hostname>[:<port>]] 
 *
 * There might be a cleaner way to write this
 *  but I'm stuck with (hostname | hostname . port)?
 *)
let hostname   = [ label "hostname" . store /[^ \t\n:]+/ ]
let port       = [ label "port"     . store num ]
let identifier = [ label "upsname" . store /[^ \t\n@]+/ ]
                   . ( ( Util.del_str "@" . hostname )
                     | ( Util.del_str "@" . hostname
                         . Util.del_str ":" . port ) )?


let upsmon_num_re = "DEADTIME"
                  | "FINALDELAY"
                  | "HOSTSYNC"
                  | "MINSUPPLIES"
                  | "NOCOMMWARNTIME"
                  | "POLLFREQ"
                  | "POLLFREQALERT"
                  | "RBWARNTIME"

let upsmon_num    = [ del_spc . key upsmon_num_re . sep_spc . store num . eol ]

let upsmon_word   = [ del_spc . key "RUN_AS_USER" . sep_spc . store word . eol ]

let upsmon_file_re = "NOTIFYCMD"
                  | "POWERDOWNFLAG"
                  | "SHUTDOWNCMD"

let sto_to_eol = IniFile.sto_to_eol
(* here we should support both quoted and not quotted
 * string but I can't manage to find the right way of doing this
 *)
let upsmon_file   = [ del_spc . key upsmon_file_re . sto_to_eol . eol ]

(* MONITOR system powervalue username password type *)
let upsmon_monitor = [ del_spc . key "MONITOR" . sep_spc
                         . [ label "system"     . identifier ] . sep_spc
                         . [ label "powervalue" . store num  ] . sep_spc
                         . [ label "username"   . store word ] . sep_spc
                         . [ label "password"   . store word ] . sep_spc
                         . [ label "type"       . store word ] . eol  ]

let upsmon_notify_type = "ONLINE"
			| "ONBATT"
			| "LOWBATT"
			| "FSD"
			| "COMMOK"
			| "COMMBAD"
			| "SHUTDOWN"
			| "REPLBATT"
			| "NOCOMM"
			| "NOPARENT"
			| "CAL"
			| "OFF"
			| "NOTOFF"
			| "BYPASS"
			| "NOTBYPASS"

let upsmon_notify = [ del_spc . key "NOTIFYMSG" . sep_spc
                         . [ label "type" . store upsmon_notify_type . sep_spc ]
                         . [ label "message" . quoted_string ] . eol ]

 let flags = "IGNORE"
		| "SYSLOG"
		| "WALL"
		| "EXEC"

let plus =  [ del /\+*/ "" ]

(*let entries = /IGNORE|SYSLOG|WALL|EXEC+/*)

let record = [ seq "record" . plus . store flags ]

let upsmon_notify_flag = [ counter "record"
			. del_spc . key "NOTIFYFLAG" . sep_spc
			. [ label "type" . store upsmon_notify_type . sep_spc ]
			. record+ . eol ]

let upsmon_record = upsmon_num|upsmon_word|upsmon_file|upsmon_monitor|upsmon_notify|upsmon_notify_flag

let upsmon_lns    = (upsmon_record|comment|empty)*

let upsmon_filter = ( incl "/etc/nut/upsmon.conf" )
			. Util.stdexcl

let upsmon_xfm    = transform upsmon_lns upsmon_filter
